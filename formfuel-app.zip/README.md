# FORM&FUEL

Mobile workout logger — implementation of the `Trainingschema prototype.html` design (see `../project/` and `../chats/` for the original design bundle).

Built with Vite + React + TypeScript. Installable as a PWA (works offline, add to home screen).

## Develop

```
npm install
npm run dev
```

Open on your phone (same network) via the "Network" URL Vite prints, or resize your browser to a mobile width — the layout is a single-column mobile view with no desktop breakpoint, matching the original design.

## Cross-device sync (optional)

Data is always saved to `localStorage` first, so the app works fully offline. If you also want your schema and logged sets to follow you across devices/browsers, wire it up to a free [Supabase](https://supabase.com) project — no login required, just one shared row:

1. Create a Supabase project.
2. In the SQL editor, run `supabase/schema.sql` from this folder.
3. Copy `.env.example` to `.env.local` and fill in the project's URL and anon key (Project Settings → API).
4. Restart `npm run dev` (or rebuild).

Without those env vars set, the app just runs on `localStorage` as before — sync is entirely optional. When enabled, the newest of the local/remote copy wins on load (by last-write timestamp), changes are pushed to Supabase ~800ms after you stop making them, and a small "offline" icon appears in the top bar if a change couldn't be synced yet.

Note the schema's RLS policy is intentionally wide open to anyone holding the anon key (scoped to a single fixed row) — that's the tradeoff for skipping accounts on a single-user app. Don't reuse it for multi-user data.

## Build

```
npm run build
npm run preview
```

## Cross-device sync

Training and nutrition sync across devices via Supabase. You sign in with a
magic link emailed to you (no password); each account has its own private row
protected by row level security. Without the Supabase env vars the app runs
local-only and shows a "use on this device only" option. See
[`SYNC_SETUP.md`](./SYNC_SETUP.md) for the one-time dashboard setup (table, RLS,
email template, env vars). Sign-out is at the bottom of the Doelen tab.

## Training / workout logging

The **Schema** tab holds your routine per weekday (a template: exercises + planned sets), editable and reorderable. The **Training** tab is the live logger, kept separate from the template so a workout never mutates your routine:

- On today's routine, **Start workout** creates a fresh session, pre-filled from your last performance of each exercise (pulled from history), with check-offs reset.
- You log set by set in the focus view (weight/reps steppers, rest timer, estimated 1RM, real "vorige keer" from history, and a **PR** flag when you beat your best estimated 1RM).
- **Afronden** writes the full session (every completed set's weight × reps, plus volume) to `workoutLog`, feeds the streak/stats, and updates "last time". Sessions are dated, so history persists — the Doelen tab lists your recent workouts with volume.

A rest day (no routine) still offers a quick "markeer als afgerond" stamp. This split (routine template ↔ dated session log) is what enables real history and progression, rather than checkboxes on a recurring schedule.

Exercises come from a **built-in library** grouped by muscle (filterable in the add screen); you can also create custom exercises (name + muscle), which are stored and synced. Names already used in your routines/history show up in the picker too, so nothing gets lost. Canonical naming keeps an exercise's history from fragmenting across spellings, and the Doelen tab shows per-exercise progression (estimated 1RM / volume / top weight over time) with the muscle group.

## Voeding / macro-tracking

The **Voeding** tab logs food per day, split across Ontbijt, Lunch, Diner and Snacks, and tracks carbohydrate, protein and fat (plus calories) against editable daily goals. A day's totals are shown as a macro ring; tap it to set your goals.

Adding food supports three routes:

- **Barcode scanner** — uses the device camera (native `BarcodeDetector` where available, `@zxing/browser` as a lazy-loaded fallback) to read EAN/UPC codes, then resolves the product to its macros. Lookups resolve in order: foods you've logged before, then a local barcode cache, then [Open Food Facts](https://world.openfoodfacts.org) (no API key). Cached and previously-logged products resolve instantly and work offline. If a code isn't found the app falls back to manual entry with the code pre-filled; being offline shows a distinct "no connection" message rather than "not found".
- **Search** — a search box matches a built-in list of common foods and, when online, queries Open Food Facts by name.
- **Eigen voeding** — enter a name and per-100 g/ml macros by hand.

Each logged item stores its macros *per 100 g/ml*, so editing the amount rescales the calories and macros automatically. Where Open Food Facts provides them, the app also captures **fibre, sugar, saturated fat and salt**, shown as a daily "Micronutriënten" strip. A per-day **water tracker** (quick +250/+500 ml, 2 L goal) sits under the day summary. Foods you've logged before appear under "Recent" in the food picker (deduped, most-recent first, remembering the last amount used) for quick re-adding. Nutrition data — including recents — is saved in the same store as the training schema and rides along on the optional Supabase sync.

Camera access requires a secure context (HTTPS or `localhost`) — the Vercel deployment and `localhost` dev server both qualify.

The **Doelen** tab summarises the week's nutrition: a 7-day bar chart that switches between calories and each macro (protein / carbs / fat) with a dashed goal line, plus average macros over the days you actually logged (shown against your daily goals). Training progress is real, computed from **logged sessions**: mark "Training van vandaag afronden" on the Training tab and the Doelen tab shows sessions this month, a consecutive-weeks streak, this week's session days, and time since your last session. It also tracks **bodyweight** — log today's weight to build a trend line with an editable target — and lets you keep **editable strength goals** (tap one to edit, or add your own). An empty day in the Voeding tab offers a "Kopieer vorige dag" button that clones the previous day's log.

Daily targets can be set two ways (tap the macro ring to switch): **manual** macro goals, or **adaptive** — you pick a goal (lose/maintain/gain at a chosen rate) and the app derives your calorie and macro targets. It estimates maintenance from your bodyweight trend and actual intake once there's enough history (least-squares weight slope vs. average logged intake), and falls back to a Mifflin–St Jeor formula estimate (from sex/age/height/activity) until then. The target then follows your weight, MacroFactor-style.

## Data backup

The Doelen tab has a **Gegevens** section to export the full store as a JSON file and to import one back (import replaces the current data after a confirm). Handy as an occasional off-device backup on top of the Supabase sync.

## Development

- `npm run dev` — dev server
- `npm run build` — type-check + production build
- `npm run lint` — oxlint
- `npm test` — unit tests (Vitest) for the nutrition math (`src/data/nutrition.test.ts`). Test files are excluded from the production build, so the deploy never depends on the test tooling.

## Notes on deviations from the design bundle

- The prototype wrapped the app in a fake iOS device frame (`ios-frame.jsx`) for previewing on a design canvas. That's dropped here — on a real phone the OS provides the status bar/home indicator, so the app fills the viewport directly and uses `env(safe-area-inset-*)` for notch/home-indicator spacing instead.
- Added a PWA manifest + service worker (installable, offline-capable) — proposed in the design chat as a near-term next step, not present in the original prototype.
